<nav class="main-header navbar navbar-expand navbar-white navbar-light">
  <ul class="navbar-nav">
    <li class="nav-item">
      <a class="nav-link" data-widget="pushmenu" href="#"><i class="fas fa-bars"></i></a>
    </li>
  </ul>
  <!-- Right navbar links -->

  <ul class="navbar-nav ml-auto">
    <div id="livekotakpertanyaan"></div>
    &nbsp;&nbsp;&nbsp;&nbsp;
    <li class="nav-item">
      <a href="#" data-toggle="modal" data-target="#logout" class="btn btn-danger">
        <i class="fas fa-power-off"></i> KELUAR
      </a>
    </li>
  </ul>
</nav>