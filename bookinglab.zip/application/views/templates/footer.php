<footer class="main-footer">
	<!-- To the right -->
	<!-- Default to the left -->
	<strong>Copyright &copy; 2023 <a href="<?php echo base_url() ?>">Siplabs ASWAJA</a>.</strong>
</footer>
</div>
<!-- jQuery -->
<script src="<?= base_url('assets/') ?>plugins/jquery/jquery.min.js"></script>
<!-- jquery print -->
<script src="<?= base_url('assets/') ?>plugins/jquery-print/jquery.print.js"></script>
<!-- Bootstrap 4 -->
<script src="<?= base_url('assets/') ?>plugins/bootstrap/js/bootstrap.bundle.min.js"></script>
<!-- SweetAlert2 -->
<script src="<?= base_url('assets/') ?>plugins/sweetalert2/sweetalert2.min.js"></script>
<!-- Toastr -->
<script src="<?= base_url('assets/') ?>plugins/toastr/toastr.min.js"></script>
<!-- AdminLTE App -->
<script src="<?= base_url('assets/') ?>dist/js/adminlte.min.js"></script>
<!-- AdminLTE for demo purposes -->
<script src="<?= base_url('assets/') ?>dist/js/demo.js"></script>

<!-- data tables -->
<script src="<?= base_url('assets/') ?>plugins/datatables/jquery.dataTables.js"></script>
<script src="<?= base_url('assets/') ?>plugins/datatables-bs4/js/dataTables.bootstrap4.js"></script>

<!-- user -->
<script src="<?= base_url('assets/') ?>dist/js/user.js"></script>
</body>

</html>